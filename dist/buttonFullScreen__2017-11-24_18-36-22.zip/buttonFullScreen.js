namespace("leesa.visual")["buttonFullScreen"] = (function (leesa, _, d3) {
  var magicalChart = {
    extend: function (quadrant) {},
    render: function (quadrant, callback) {
      var fullScreen = false;
      var content = quadrant.htmlJContent();
      var parent = content.parent();
      var body = $("body");
      content.html("");
      content.addClass("button-fullscreen");
      var visual = quadrant.visual();
      var data = quadrant.data();
      var parameters = visual.parameters || {};
      // var _visualIdentifier = "buttonFullScreen";//uncomment to see what values you have
      // console.log(_visualIdentifier +" Quadrant:",quadrant) 
      // console.log(_visualIdentifier +" Visual:",visual) 
      // console.log(_visualIdentifier +" Data:",data);
      // console.log(_visualIdentifier +" Parameters:",parameters);
      var button = $("<button class='waves-effect dftz__full-width  button button--green button--medium button--shadow'>Full Screen</button>");
      button.appendTo(content);
      button.click(toggleFullScreen);

      function toggleFullScreen() {
        console.log(fullScreen);
        fullScreen = !fullScreen;
        refreshFullScreen();
      }

      function refreshFullScreen() {
        if (fullScreen) {
          content.appendTo(body);
          content.addClass("button-fullscreen--full");
        } else {
          content.appendTo(parent);
          content.removeClass("button-fullscreen-full");
        }
      }
    },
    configuration: {},
  }
  return magicalChart;
})(leesa, _, d3)